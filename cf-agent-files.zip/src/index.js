// src/index.js
import { Router } from 'itty-router';

const router = Router();

// Health check endpoint
router.get('/health', () => {
  return new Response(JSON.stringify({ status: 'healthy', timestamp: Date.now() }), {
    headers: { 'Content-Type': 'application/json' }
  });
});

// Main worker handler
router.get('/', () => {
  return new Response('CF Agent is running!', { 
    headers: { 'Content-Type': 'text/plain' } 
  });
});

// Handle POST requests
router.post('/api/webhook', async (request) => {
  const body = await request.json();
  
  // Process webhook data
  console.log('Received webhook:', body);
  
  return new Response(JSON.stringify({ success: true, receivedAt: Date.now() }), {
    headers: { 'Content-Type': 'application/json' }
  });
});

// 404 for everything else
router.all('*', () => new Response('Not Found', { status: 404 }));

// Export the worker
export default {
  async fetch(request, env, ctx) {
    return router.handle(request);
  }
};